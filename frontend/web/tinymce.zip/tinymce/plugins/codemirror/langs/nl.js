tinymce.addI18n('nl',{
	'HTML source code': 'HTML broncode',
	'Start search': 'Start zoeken',
	'Find next': 'Zoek volgende',
	'Find previous': 'Zoek vorige',
	'Replace': 'Vervang',
	'Replace all': 'Vervang alle'
});
